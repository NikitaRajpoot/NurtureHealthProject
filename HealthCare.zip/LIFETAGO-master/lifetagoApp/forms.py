# from django import forms
# from .models import Appointments

# class AppointmentsForm(forms.ModelForm):
#     class Meta:
#         model = Appointments
#         #fields = "__all__"
#         exclude = ["patient","doctor","department_id","status"]
#         labels = {
#                 "contact": "Mobile No.",
#                 }
#         widgets = {
#                 'contact': forms.NumberInput(attrs={'class':'form-control'}),
#                 'date': forms.DateInput(attrs={'class':'form-control'}),
#                 'time': forms.TimeInput(attrs={'class':'form-control'}),
#                 'message': forms.Textarea(attrs={'class':'form-control','style':'resize:none;'}),
#                 } 