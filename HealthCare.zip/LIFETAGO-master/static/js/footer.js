$(function(){
    $(".footer-link").mouseover(function(){
        $(this).css({transition:"0.5s",
                                color:"#00bb6d",
                                left:"5px",
                                "text-decoration": "none",
                                })
                            })

    $(".footer-link").mouseout(function(){
        $(this).css({transition:"0.5s",
                                color:"white",
                                left:"0px",
                                })
                            })
})